/** Automatically generated file. DO NOT MODIFY */
package fr.polytech.video;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}